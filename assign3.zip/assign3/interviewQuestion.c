
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
    FILE *file;
    file = fopen("interviewQuestion.txt", "r");
    char ch;
    int letters[26][1];
    //printf("%d ", sizeof(letters[]))
    for (int i = 0; i < 26; i++)
    {
        letters[i][0] = 0;
    }
    while ((ch = fgetc(file)) != EOF)
    {
        if (isalpha(ch))
        {
            char c = tolower(ch);
            // a - 97
            //...
            //...
            // z - 122
            letters[c - 97][0]++;
        }
    }
    for (int i = 0; i < 26; i++)
    {
        printf("%c: %d\n ", i+97, letters[i][0]);
    }

    return 0;
}