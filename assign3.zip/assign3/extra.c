#include <stdio.h>

int x,y;
x = 7;
y = x--;
x = --y;
printf("%d", y++);